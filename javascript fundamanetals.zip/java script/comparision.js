//write a program to compare the strings and the numbers by using comparision operators
var a="hello";
var b="hello";
console.log(a==b);
console.log(a<b);
console.log(a!=b);
var num1=100;
var num2=5;
console.log(num1==num2);
console.log(num1<num2);
console.log(num1>num2);
console.log(num1!=num2);
