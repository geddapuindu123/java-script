//if the person result is more than 9o percent say 'hi'other than say 'bye'.
var indu=45;
if(indu>=90){
    console.log("hi");
}
else{
    console.log("bye");
}