//write a program to print the total attendance of st domain
var a;
for(a=211801340001;a<=211801340021;a++)
{
    console.log(a +" :is present")
}