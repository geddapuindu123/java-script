//write a program to print the grades of the students based on the marks.
var marks=74;

if(marks>=90)
{
    console.log("grade O");
}
else if(marks>=80)
{
    console.log("grade E");
}
else if(marks>=70)
{
    console.log("grade A");
}
else if(marks>=60)
{
    console.log("grade B");
}
else if(marks>=50)
{
    console.log("grade B");
}
else{
    console.log("fail");
}