function indu()
{
    console.log("hello indu")
}
indu();
indu();
indu();