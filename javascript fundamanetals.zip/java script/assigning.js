//write a program on assignment operators
var num1=24;
var num2=35;
var num3=45;
var num4=105;

num1+=5;
console.log(num1);
num2*=4;
console.log(num2);
num3%=5;
console.log(num3);
num4/=7;
console.log(num4);