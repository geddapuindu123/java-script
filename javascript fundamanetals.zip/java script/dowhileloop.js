//print the particular statement using the do while loop
var a=1
do{
   console.log("hi hello");
   a++;
}
while(a<=10);
