//write a program on details about the student using variables
var name="indu",number=5,dept="cse";
console.log("student_name: ",name);
console.log("roll_no: ",number);
console.log("department: ",dept);