//write a program to perform the basic operations between the two numbers
var a=45;
var b=9;
var addition,difference,product,division,modulus;
switch(addition)
{
    case addition:
        c=a+b;
        console.log("value is: ",c);
    break;
    case difference:
        d=a-b;
        console.log("value is: ",d);
    break;
    case product:
        e=a*b;
        console.log("value is: ",e);
    break;
    case division:
        f=a/b;
        console.log("value is: ",f);
    break;
    case modulus:
        g=a%b;
        console.log("value is: ",g);
    break;

    default:console.log("nothing is selected");
 }