//write a program to find types of given values
var a="indu";
var b=5;
var c='c';
var d=true;
var g;
console.log(typeof a);
console.log(typeof b);
console.log(typeof c);
console.log(typeof d);
console.log(typeof g);

