//write a program on the any two numbers using logical operators 
var num1=25;
var num2=36;
console.log(num1<num2 && num2<num1);
console.log(num1<num2 || num2<num1);
name1="indu";
name2="sunnu";
console.log(!(name1==name2));
console.log(!(name1!=name2));
console.log(!(100/5==0));
console.log((name1==name2));