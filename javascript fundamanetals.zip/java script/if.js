//if the two persons saying the same wishes to both then print something
var sunnu="hi";
var indu="hi";
if(sunnu==indu)
{
    console.log("hello");
}