//write a program to find the square values of the first ten numbers using whie loop
var a,s;
a=1;
while(a<=10)
{
    s=a*a;
    console.log("square of number= ",s);
    a++;
}
