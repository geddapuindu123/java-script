//function return
function indu(){
    return "hello indu"
}
var hi=indu();
console.log(hi);