//find the root value of the particular number using with parameters
function usr(a){
    c=a**0.5;
    console.log(c);
}
usr(2);