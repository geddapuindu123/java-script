//write a program to perform the operations on arithmetic operators
var num1=20;
var num2=4;
//addition
sum=num1+num2;
console.log("addition of 20 and 4 is: ",sum);
//substraction
difference=num1-num2;
console.log("difference between 20 and 4 is: ",difference);
//multiplication
multiplication=num1*num2;
console.log("the product of 20 and 4 is: ",multiplication);
//modulus
modulus=num1%num2;
console.log("modulus of 20 and 4 is: ",modulus);
//division
division=num1/num2;
console.log("division of 20 and 4 is: ",division);