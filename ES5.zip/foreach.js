//example-1
var data=["hi","hello","indu"]
data.forEach(
    function (indu){
        console.log(indu);
    }
)

//exa,ple-2
var arr=[1,2,3,4,5,"a","b","c","d","e"]
arr.forEach(
    function (name){
        console.log(name);
    }
)