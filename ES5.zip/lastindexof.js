
a=['a',1,2,3,4,3,"we",1,2,3,1,2,2,]
console.log(a.lastIndexOf(2))


a=['a',1,2,3,4,3]
console.log(a.lastIndexOf(3))