//example-1
var arr=[1,2,3,4];
console.log(Array.isArray(arr));
//example-2
var arr1=5;
console.log(Array.isArray(arr1));