//example-1
var hi={
    name :"indu",
    number :5 
}
 var hello = JSON.stringify(hi);
 console.log(hello);

 //example-2
 var indu={
    id :5,
    name:"hi"
 }
 var hello=JSON.stringify(indu);
 console.log(hello);