//example-1
var indu=["indu","abc","def","paddu"];
 var paddu=indu.every(
    function (abc){
        return abc.length>2;
    }
 )
 console.log(paddu)

 //example-2
 var a=[1,2,3,4,5,6,7,8,9];
 var b=a.every(
    function (hi){
        return hi.b/2==0;
    }
 )
 console.log(b);