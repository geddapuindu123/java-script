//example-1
var arr=[1,2,3,4,5,6,7];
 var hello =arr.filter(
   function(hi){
    return hi>3;
   }
 )
 console.log(hello);

 //example-2
 var indu=["indu","abc","def","paddu"];
 var paddu=indu.filter(
    function (abc){
        return abc.length>4;
    }
 )
 console.log(paddu);