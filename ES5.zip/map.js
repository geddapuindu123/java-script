//example-1
var a=[1,2,3,4,5,6]
a.map(
    function (hello){
        console.log(hello);
    }
)

//example-2
var arr=["a","b","c","d","e","f"];
 var hi=arr.map(
function (hi){
      return hi+"l";
}
    )
    console.log(hi)