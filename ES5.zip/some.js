//example-1
var a=[1,2,3,4,5,6,7,8]
var b=a.some(
    function (hi){
        return hi>0;
    }
)
console.log(b)

//example-2
var indu=[5,10,12,23,435,34];
var paddu=indu.some(
    function (hello){
        return hello>1;
    }
)
console.log(paddu);
