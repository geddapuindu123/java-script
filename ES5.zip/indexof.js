 data=[1,'indu',3,4,5,6,7,8,9]
console.log(data.indexOf(3))


data=[1,'indu',3,4,5,6,7,8,9]
console.log(data[4])